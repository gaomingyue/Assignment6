import java.awt.BorderLayout;
import javax.swing.JScrollPane;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class willBuy extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public void  willBuy() {
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 471, 497);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(56, 76, 346, 220);
		contentPane.add(textArea);
		
		try{
			Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456"); 
		
			String sql="select * from willbuy";
			 Statement stmt = conn.createStatement();
			  ResultSet rs=stmt.executeQuery(sql);
			 String show="name\tevery\tnumber\ttotal\r\n";
			 
				while (rs.next()){
					String name=rs.getString("Name");
					String every=rs.getString(String.valueOf("Every"));
					String number=rs.getString(String.valueOf("Number"));
					String total= rs.getString(String.valueOf("Total"));
				        show=show+name+"\t"+every+"\t"+number+"\t"+total+"\r\n";
				      
				}
				  textArea.setText(show);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(55, 75, 355, 230);
	    contentPane.add(scrollPane);
		
		JLabel label = new JLabel("\u8D2D\u7269\u8F66");
		label.setFont(new Font("΢���ź�", Font.BOLD, 20));
		label.setBounds(194, 29, 89, 37);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setBounds(234, 321, 146, 28);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("\u6E05\u7B97");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			try{
				Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456"); 
			
				String sql="select * from willbuy";
				 Statement stmt = conn.createStatement();
				  ResultSet rs=stmt.executeQuery(sql);
				  int alltotal=0;
				 
					while (rs.next()){
						  int total= rs.getInt("Total");
					        alltotal=alltotal+total;
					      
					}
					  textField.setText(String.valueOf(alltotal));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		button.setBounds(56, 321, 168, 31);
		contentPane.add(button);
		
		
		
		JLabel label_1 = new JLabel("\u5143");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 13));
		label_1.setBounds(390, 329, 41, 15);
		contentPane.add(label_1);
		
		
		
		JButton btnNewButton = new JButton("\u4E00\u952E\u8D2D\u4E70");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				signResult srw=new signResult("����ɹ�");
				srw.result();
				try{
					Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456"); 
				String sqlw2 = "delete from willbuy where Name=name";
             	 Statement stmt2 = conn.createStatement();
             	
					stmt2.executeUpdate(sqlw2);
					textArea.setText(null);
				 } catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		});
		btnNewButton.setBounds(56, 362, 346, 61);
		contentPane.add(btnNewButton);
		
		JButton button_1 = new JButton("\u6E05\u7A7A\u8D2D\u7269\u8F66");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
					try{
						Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456"); 
					String sqlw = "delete from willbuy where Name=name";
	              	 Statement stmt1 = conn.createStatement();
	              	 textArea.setText(null);
	              	 stmt1.executeUpdate(sqlw);
					 } catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			}
		});
		button_1.setBounds(350, 0, 105, 23);
		contentPane.add(button_1);
		
	}
}
