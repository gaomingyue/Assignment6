import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class firstGUI extends JFrame {
	public firstGUI() {
	}
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	
	
	
	public void firstGUI() {
		setTitle("��¼");
		getContentPane().setLayout(null);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 20,400, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("��������ƽ̨");
		lblNewLabel.setBounds(149, 33, 80, 25);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("�û���");
		lblNewLabel_1.setBounds(44, 83, 45, 15);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(100, 80, 200, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("����");
		label.setBounds(52, 140, 30, 15);
		contentPane.add(label);
		
		textField_1 = new JTextField();
		textField_1.setBounds(100, 137, 200, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton button = new JButton("ע��");
		button.setBounds(210, 194, 93, 23);
		contentPane.add(button);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			signIn signin=new signIn();
			signin.signIn();
					
			}
		});
		
		JButton button_1 = new JButton("��¼");
		button_1.setVisible(true);
		button_1.setBounds(98, 194, 93, 23);
		contentPane.add(button_1);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String user0=textField.getText();
				String password0=textField_1.getText();
				try {
					Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456"); 
				String sql="select * from signin";
				 Statement stmt = conn.createStatement();
				  ResultSet rs=stmt.executeQuery(sql);
				  boolean see=false;
				  while (rs.next()){
					  String user1 = rs.getString("user");
		                String password1 = rs.getString("password");
		                if(user0.equals(user1)&&password0.equals(password1)){
		                	see=true;
		                }
				  }
				  if(see){
					  setVisible(false);
					  petSail ps=new petSail();
					  ps.petSail();
				  }
				  else{
					  signResult sr=new signResult("��¼ʧ��");
					  sr.result();
				  }
				 
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
					
			}
		});
	}

	

	
}
