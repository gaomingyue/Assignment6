import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;


/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class Detail extends JFrame {
	private String name;
	private String eat;
	private String drink;
	private String live;
	private String hobby;
	private int  price;
	/**
	 * @param string
	 * @param string2
	 * @param string3
	 * @param string4
	 * @param string5
	 */
	

	public Detail(String name,String eat,String drink,String live,String hobby,int price){
		this.name=name;
		this.eat=eat;
		this.drink=drink;
		this.live=live;
		this.hobby=hobby;
		this.price=price;
	}

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	
	/**
	 * Create the frame.
	 */
	public void detail() {
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 350, 480);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblName.setBounds(80, 50, 60, 30);
		contentPane.add(lblName);
		
		JLabel lblName_1 = new JLabel(name);
		lblName_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblName_1.setBounds(140, 50, 100, 30);
		contentPane.add(lblName_1);
		
		JLabel lblEat = new JLabel("Eat:");
		lblEat.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblEat.setBounds(80, 90, 60, 30);
		contentPane.add(lblEat);
		
		JLabel lblEat_1 = new JLabel(eat);
		lblEat_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblEat_1.setBounds(140, 90, 200, 30);
		contentPane.add(lblEat_1);
		
		JLabel lblNewLabel = new JLabel("Live:");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblNewLabel.setBounds(80, 130, 60, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblLive = new JLabel(live);
		lblLive.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblLive.setBounds(140, 130, 200, 30);
		contentPane.add(lblLive);
		
		JLabel lblDrink = new JLabel("Drink:");
		lblDrink.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblDrink.setBounds(80, 170, 60, 30);
		contentPane.add(lblDrink);
		
		JLabel lblNewLabel_1 = new JLabel(drink);
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(140, 170, 100, 30);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblHobby = new JLabel("Hobby:");
		lblHobby.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblHobby.setBounds(80, 210, 60, 30);
		contentPane.add(lblHobby);
		
		JLabel lblNewLabel_2 = new JLabel(hobby);
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(140, 210, 100, 30);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblPrice = new JLabel("Price:");
		lblPrice.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblPrice.setBounds(80, 250, 60, 30);
		contentPane.add(lblPrice);
		
		JLabel lblNewLabel2 = new JLabel(String.valueOf(price));
		lblNewLabel2.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblNewLabel2.setBounds(140, 250, 100, 30);
		contentPane.add(lblNewLabel2);
		
		JButton btnNewButton = new JButton("\u52A0\u5165\u8D2D\u7269\u8F66");
		btnNewButton.setBounds(75, 325, 144, 30);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 boolean see=false;
				 Connection conn;
				 int i = 0;
				try {
					conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
				
				String sql="select * from willbuy";
				 Statement stmt = conn.createStatement();
				  ResultSet rs=stmt.executeQuery(sql);
				
				  while (rs.next()){
					  String Name = rs.getString("Name");
		                //String password1 = rs.getString("password");
		                if(name.equals(Name)){
		                	see=true;
		                	i=rs.getInt("Number");
		                }
				  } 
				  if(see){
					  int j=i+1;
					  int k=j*price;
		              	String sql11 = "update willbuy set Number='"+j+"'  where Name='"+name+"'";
		              	String sql12 = "update willbuy set Total='"+k+"' where Name='"+name+"'";
		              	 Statement stmt1 = conn.createStatement();
		              	 stmt1.executeUpdate(sql11);
		              	stmt1.executeUpdate(sql12);
		              }
				  else{
					  Statement stmt2 = conn.createStatement();
						// stmt.execute("set names gb2312");
						 String sql2 = "insert into willbuy(Name,Every,Number,Total) "
			                		+ "values('"+name+"','"+price+"','"+1+"','"+price+"')";
					     
					      stmt2.executeUpdate(sql2);	
				  }
				  }
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				 
					
			}
		});
		
		JButton btnNewButton1 = new JButton("������һ��");
		btnNewButton1.setBounds(75, 370, 144, 30);
		contentPane.add(btnNewButton1);
		btnNewButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
	}

}
