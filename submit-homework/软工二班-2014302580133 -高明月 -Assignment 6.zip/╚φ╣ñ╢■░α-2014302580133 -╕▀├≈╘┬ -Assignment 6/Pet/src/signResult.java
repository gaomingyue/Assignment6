import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class signResult extends JFrame {

	String result;
	public signResult(String result){
		this.result=result;
	}
	

	private JPanel contentPane;
	public void result() {
		setVisible(true);
		//setTitle("ע����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel(result);
		label.setBounds(112, 45, 60, 30);
		contentPane.add(label);
		
		JButton button = new JButton("����");
		button.setBounds(112, 90, 70, 23);
		contentPane.add(button);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		setVisible(false);
					
			}
		});
	}

}

