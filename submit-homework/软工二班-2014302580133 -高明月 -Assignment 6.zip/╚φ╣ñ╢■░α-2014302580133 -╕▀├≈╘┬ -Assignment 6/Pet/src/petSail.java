import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.*;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class petSail extends JFrame {
	

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public void  petSail() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 491);
		setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		
        getContentPane().setLayout(null);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Dog");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("dog","bone","water","ground","play",200);
				dt.detail();//'bone','water','ground','play'
			}
		});
		btnNewButton.setBounds(50, 85, 90, 90);
		getContentPane().add(btnNewButton);
		
		JButton btnCat = new JButton("Cat");
		btnCat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("cat","fish","milk","roof","hug",100);
				dt.detail();//'cat','fish','milk','roof','hug'
			}
		});
		
		btnCat.setBounds(150, 85, 90, 90);
		getContentPane().add(btnCat);
		
		JButton btnTurtle = new JButton("Turtle");
		btnTurtle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("turtle","fish,shrimp","sea water","sea water","bask",500);
			    dt.detail();//'turtle','fish,shrimp','sea water','sea water','bask'
			}
		});
		btnTurtle.setBounds(250, 85, 90, 90);
		contentPane.add(btnTurtle);
		
		JButton btnParrot = new JButton("Parrot");
		btnParrot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("parrot","nuts,seeds","water","tree","fly",50);
			    dt.detail();//(4,'parrot','nuts,seeds','water','tree','fly')
			}
		});
		btnParrot.setBounds(350, 85, 90, 90);
		contentPane.add(btnParrot);
		
		JButton btnHamster = new JButton("Hamster");
		btnHamster.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("hamster","Sunflower seed","water","corner","eat",30);
			    dt.detail();//(5,'hamster','Sunflower seed','water','Sunflower seed','eat')
			}
		});
		btnHamster.setBounds(50, 185, 90, 90);
		contentPane.add(btnHamster);
		
		JButton btnX = new JButton("Squirrel");
		btnX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("squirrel","pine cone","water","tree hole,underground","play",150);
			    dt.detail();//'squirrel','pine cone','water','tree hole,underground','play'
			}
		});
		btnX.setBounds(150, 185, 90, 90);
		contentPane.add(btnX);
		
		JLabel label = new JLabel("\u5BA0\u7269\u9500\u552E");
		label.setFont(new Font("΢���ź�", Font.BOLD, 18));
		label.setBounds(212, 26, 81, 45);
		contentPane.add(label);
		
		JButton btnNewButton_1 = new JButton("\u8D2D\u7269\u8F66");
		btnNewButton_1.setBounds(391, 0, 93, 23);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				willBuy wbp=new willBuy();
				wbp.willBuy();
			}
		});
		
		JButton btnNewButton_2 = new JButton("Rabbit");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("rabbit","carrot","water","grassland,underground","eat",20);
			    dt.detail();//(7,'rabbit','carrot','water','grassland,underground','eat')
			}
		});
		btnNewButton_2.setBounds(250, 185, 90, 90);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Snake");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("snake","mouse","water","hole","bask",60);
			    dt.detail();//8,'snake','mouse','water','hole','bask'
			}
		});
		btnNewButton_3.setBounds(350, 185, 90, 90);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Lizard");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("lizard","bug","water","tree","bask",250);
			    dt.detail();//9,'lizard','bug','water','tree','bask'
			}
		});
		btnNewButton_4.setBounds(50, 285, 90, 90);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Fish");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("fish","aquatic plant","water","wate","swim",10);
			    dt.detail();//10,'fish','aquatic plant','water','water','swim'
			}
		});
		btnNewButton_5.setBounds(150, 285, 90, 90);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Myna");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("myna","earthworm","water","tree","fly",70);
			    dt.detail();//11,'myna','earthworm','water','tree','fly'
			}
		});
		btnNewButton_6.setBounds(250, 285, 90, 90);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Canary");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Detail dt=new Detail("canary","millet","water","tree","sing",320);
			    dt.detail();//12,'canary','millet','water','tree','sing'
			}
		});
		btnNewButton_7.setBounds(350, 285, 90, 90);
		contentPane.add(btnNewButton_7);
		
		JLabel label_1 = new JLabel("\u70B9\u51FB\u76F8\u5E94\u6309\u94AE\u67E5\u770B\u8BE6\u60C5");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_1.setBounds(183, 398, 162, 15);
		contentPane.add(label_1);
		
		//Image image=new ImageIcon("E:/eclipse files/Pet/src/dog.jpg").getImage();
		//JLabel label1 = new JLabel(new ImageIcon("dog.jpg"));
		
		//contentPane.add(label1);
		
	}
}
