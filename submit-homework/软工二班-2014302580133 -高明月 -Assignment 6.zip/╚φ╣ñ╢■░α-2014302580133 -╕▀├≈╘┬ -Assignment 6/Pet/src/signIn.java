import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class signIn extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	//static String user;
	//static String password1;
	//String password2;
	/**
	 * Launch the application.
	 */
	
	/**
	 * Create the frame.
	 */
	public void signIn() {
		setTitle("\u6CE8\u518C");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 341, 266);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSignIn = new JLabel("Sign In");
		lblSignIn.setBounds(143, 10, 63, 41);
		contentPane.add(lblSignIn);
		
		JLabel label = new JLabel("\u7528\u6237\u540D");
		label.setBounds(44, 64, 54, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u5BC6\u7801");
		label_1.setBounds(44, 101, 54, 15);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u5BC6\u7801\u786E\u8BA4");
		label_2.setBounds(29, 142, 63, 15);
		contentPane.add(label_2);
		
		textField = new JTextField();
		textField.setBounds(90, 61, 200, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(90, 101, 200, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(90, 141, 200, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
	
		
		JButton button = new JButton("\u6CE8\u518C");
		button.setBounds(125, 180, 93, 23);
		contentPane.add(button);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String user=textField.getText();
				String password1=textField_1.getText();
				String password2=textField_2.getText();
				if(password1.equals(password2))
				{
					try {
					 Connection connect;
					connect = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
				
						 Statement stmt = connect.createStatement();
						// stmt.execute("set names gb2312");
						 String sql = "insert into signin(user,password) "
			                		+ "values('"+user+"','"+password1+"')";
					     
					      stmt.executeUpdate(sql);	
					      signResult sr=new signResult("ע��ɹ�");
					      sr.result();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				}
				else{
					signResult sr1=new signResult("ע��ʧ��");
				      sr1.result();
				}
				
				setVisible(false);
				
			}
		});
		
		
		
		
	}

}


